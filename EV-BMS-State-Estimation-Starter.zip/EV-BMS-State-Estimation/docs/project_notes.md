# Project notes and assumptions

## Model
The starter demo uses a scalar random-walk model for state of charge (SOC). The state prediction remains the previous estimate, and process variance allows uncertainty to grow. Each valid SOC-like observation updates the estimate through a scalar Kalman gain.

## Communication robustness in this demo
The example rejects missing/non-finite readings and readings outside 0–100%. This is only a basic plausibility check. It does not implement a real transport protocol, encryption, CRC, packet retransmission, or real-time guarantees.

## Limitations
- All data are synthetic.
- SOC is simplified and not derived from electrochemical battery dynamics or coulomb counting.
- The demo does not estimate state of health (SOH), temperature, or internal resistance.
- The chosen noise parameters are illustrative, not experimentally calibrated.
- Do not connect this example directly to a real battery pack, BMS, charger, or vehicle controller.

## Good next steps for an academic project
1. Explain the system architecture and assumptions in a report.
2. Collect or use a clearly cited public dataset, if permitted.
3. Compare raw readings and filtered estimates using MAE/RMSE.
4. Test delayed, dropped, duplicated, and out-of-range messages.
5. Document any hardware/software integration and safety review.
