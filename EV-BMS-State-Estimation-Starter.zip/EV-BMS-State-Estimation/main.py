"""
Educational demo: EV BMS state estimation using a one-state Kalman filter.

This simulation uses synthetic data only. It is not intended for real battery
control or vehicle use.
"""
from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt


def validate_measurement(value: float, lower: float = 0.0, upper: float = 100.0) -> bool:
    """Basic plausibility check for an SOC measurement in percent."""
    return np.isfinite(value) and lower <= value <= upper


def kalman_soc_estimate(
    measurements: np.ndarray,
    process_variance: float = 0.05,
    measurement_variance: float = 4.0,
    initial_estimate: float = 100.0,
    initial_variance: float = 10.0,
) -> np.ndarray:
    """Estimate SOC (%) from noisy observations with a scalar Kalman filter."""
    estimate = float(initial_estimate)
    variance = float(initial_variance)
    estimates = []

    for measurement in measurements:
        # Prediction: random-walk model, so predicted state is unchanged.
        predicted_estimate = estimate
        predicted_variance = variance + process_variance

        if validate_measurement(float(measurement)):
            gain = predicted_variance / (predicted_variance + measurement_variance)
            estimate = predicted_estimate + gain * (float(measurement) - predicted_estimate)
            variance = (1.0 - gain) * predicted_variance
        else:
            # Reject invalid communication/measurement sample and keep prediction.
            estimate = predicted_estimate
            variance = predicted_variance

        estimates.append(estimate)

    return np.asarray(estimates)


def main() -> None:
    rng = np.random.default_rng(7)
    samples = 120
    time_min = np.arange(samples)

    # Synthetic SOC decreases gradually, as a simple illustrative discharge profile.
    true_soc = np.clip(100.0 - 0.45 * time_min, 0.0, 100.0)
    noisy_soc = true_soc + rng.normal(0.0, 2.0, size=samples)

    # Demonstrate a few corrupted/out-of-range communication readings.
    noisy_soc[25] = np.nan
    noisy_soc[60] = 145.0
    noisy_soc[90] = -12.0

    estimates = kalman_soc_estimate(noisy_soc)
    valid = np.array([validate_measurement(float(v)) for v in noisy_soc])

    plt.figure(figsize=(10, 5.5))
    plt.plot(time_min, true_soc, label="Simulated true SOC", linewidth=2)
    plt.scatter(time_min[valid], noisy_soc[valid], label="Valid noisy measurements", s=14)
    plt.scatter(time_min[~valid], np.nan_to_num(noisy_soc[~valid], nan=0.0),
                label="Rejected/corrupted samples", marker="x", s=55)
    plt.plot(time_min, estimates, label="Kalman filter estimate", linewidth=2)
    plt.xlabel("Time step (illustrative minutes)")
    plt.ylabel("State of Charge (%)")
    plt.title("Educational EV BMS SOC Estimation Demo")
    plt.ylim(-5, 110)
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig("soc_estimation_demo.png", dpi=160)
    print("Demo complete. Plot saved as soc_estimation_demo.png")
    print(f"Final simulated SOC: {true_soc[-1]:.2f}%")
    print(f"Final estimated SOC: {estimates[-1]:.2f}%")


if __name__ == "__main__":
    main()
