# EV Battery Management System (BMS) State Estimation

**Project title:** State Estimation of BMS in EV Routing with Kalman Filter and Robust Communication

## Overview
This repository is a starter template for an academic EV two-wheeler Battery Management System (BMS) project. It demonstrates the structure for estimating battery state from noisy measurements and handling communication data with basic validation.

> Important: This is a starter/demo implementation, not a validated battery-management system. Do not use it to control a real battery pack or vehicle without expert review, testing, and appropriate safety protections.

## Problem statement
Battery measurements such as voltage and current can contain noise, while communication between sensors and a controller may be delayed or corrupted. Inaccurate state estimates can affect range prediction and battery monitoring. This project provides a small simulation to explore filtering noisy measurements and rejecting invalid communication samples.

## Starter features
- Simulated battery state-of-charge (SOC) trend.
- A simple Kalman filter for a one-state SOC estimate.
- Simulated measurement noise.
- Basic communication checks for missing, non-finite, or out-of-range measurements.
- A plot comparing true SOC, noisy measurements, and estimated SOC.

## Requirements
- Python 3.10+
- `numpy`
- `matplotlib`

Install dependencies:
```bash
pip install -r requirements.txt
```

Run:
```bash
python main.py
```

## Files
- `main.py` — simulation, filter, communication validation, and plot.
- `requirements.txt` — Python dependencies.
- `docs/project_notes.md` — assumptions and possible extensions.

## Suggested extensions
1. Replace the simulated data with recorded battery measurements.
2. Tune process and measurement noise using experiments.
3. Add timestamp/sequence-number checks and a documented packet format.
4. Compare the estimate with a trusted reference and report error metrics.
5. Add tests and safety review before any hardware integration.
